# -*- coding: utf-8 -*-
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
mnist = tf.keras.datasets.mnist

(trainX, trainY),(testX, testY) = mnist.load_data()
trainX = tf.keras.utils.normalize(trainX, axis = 1)
testX = tf.keras.utils.normalize(testX, axis = 1)



if __name__ == '__main__':
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Flatten())
    model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
    model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
    model.add(tf.keras.layers.Dense(10, activation=tf.nn.softmax))

    model.compile(optimiser = 'adam',
                loss = 'sparse_categorical_crossentropy',
                metrics = ['accuracy']
                )    
    model.fit(trainX,trainY,epochs = 3)
    model.save('digit_classifier.sav')

#new_one = tf.keras.models.load_model('digit_classifier.sav')

#predict = new_one.predict([testX])
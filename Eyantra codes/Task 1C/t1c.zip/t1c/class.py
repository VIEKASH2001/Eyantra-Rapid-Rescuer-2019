import tensorflow as tf
from mnist import testX, testY
import numpy as np
import matplotlib.pyplot as plt
import cv2

digit_model = tf.keras.models.load_model('digit_classifier.sav')
img=plt.imread("/home/akesh/Downloads/eyantra/task 1/2. Practice/Task 1C/codes/img30.png")
#dk=np.array([10,28,28],dtype=uint)
#dk[0]=img
print(img)
img= tf.keras.utils.normalize(img, axis = 1)
predict = digit_model.predict([img])

print(np.argmax(predict[0]))
